<!DOCTYPE html>
<html>
<head>
<title>Contact Us Email</title>
</head>
<body>

<p><b><?php echo $data['name']; ?> Contact with us,</p>

<p><b>Title :</b> <?php echo $data['title']; ?> </p>
<p><b>Message :</b> <?php echo $data['message']; ?> </p>


Thanks

Iam Team
</body>
</html>